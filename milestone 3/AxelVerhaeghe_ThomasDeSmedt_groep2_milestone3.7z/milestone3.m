clear();
BWusage = 100;
visualize_demod;

pause;

clear();
BWusage = 50;
visualize_demod;